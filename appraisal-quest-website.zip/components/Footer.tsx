
export default function Footer(){

return(

<footer className="bg-gray-900 text-gray-300 py-10 mt-20 text-center">

<p className="font-semibold text-white">
Appraisal Quest Co.
</p>

<p>Phone: (805) 469-3088</p>

<p className="text-sm mt-4">
© 2026 Appraisal Quest Co.
</p>

</footer>

)

}
