
export default function Reviews(){

return(

<section className="bg-gray-100 py-20">

<div className="max-w-6xl mx-auto text-center">

<h3 className="text-3xl font-bold mb-10">
Client Reviews
</h3>

<p className="mb-6">Add your Google Reviews embed here.</p>

</div>

</section>

)

}
