
export default function Map(){
return(
<iframe
src="https://maps.google.com/maps?q=ventura%20county&t=&z=11&ie=UTF8&iwloc=&output=embed"
className="w-full h-[400px]"
/>
)
}
